=begin
version.rb
Copyright (c) 2007-2023 University of British Columbia
=end

$VERSION = "0.1.2"
$RELEASE_DATE = "2023-07-31"
