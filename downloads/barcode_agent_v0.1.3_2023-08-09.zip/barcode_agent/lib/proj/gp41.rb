=begin
gp41.rb
Copyright (c) 2007-2023 University of British Columbia

=end

class GP41Methods
  def GP41Methods.adjust_alignment(aligned_data)

  end
end

ProjectMethods.classes['GP41'] = GP41Methods
