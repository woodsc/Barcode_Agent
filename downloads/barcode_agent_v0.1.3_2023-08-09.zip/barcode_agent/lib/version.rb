=begin
version.rb
Copyright (c) 2007-2023 University of British Columbia
=end

$VERSION = "0.1.3"
$RELEASE_DATE = "2023-08-09"
